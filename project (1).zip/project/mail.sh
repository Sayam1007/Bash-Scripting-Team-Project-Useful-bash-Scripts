#! /bin/bash

echo "this is message body" | mutt -a "fileA.txt" -s "File Attachment"  -- sayamsobti@gmail.com
echo "Mail delivered"



