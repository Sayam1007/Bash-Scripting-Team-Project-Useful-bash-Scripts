#!/bin/bash
sudo apt update
